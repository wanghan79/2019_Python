import tkinter as tk
from plot import DrawPicture
from Generate_Data import Generate_Data
from Connect_MongoDB import Connect_Db
import matplotlib.pyplot as plt
from plot import DrawPicture
from Generate_Data import Generate_Data
from Connect_MongoDB import Connect_Db
import matplotlib.pyplot as plt

"""
    本文件为GUI模块和前三功能的结合，直接实例化与静态调用混合
    GUI模块，逻辑和设计部分分离较为清晰，比较直观，可以循环生成多个图形，
    需要选定左侧图像类型和右侧可视化数据类型。
"""

if __name__ == '__main__':
    size = 1000
    #实例化MongoDB连接类
    MongoDB = Connect_Db()
    db, collection, client = MongoDB.connet_db()
    MongoDB.isExist(client)
    #实例化随机生成数据类
    GenData = Generate_Data()
    GenData.PutIntoDataBase(collection)

    window = tk.Tk()
    window.title('胡泽彬2017011958')
    window.geometry('400x600')

    #定义标题模块
    L = tk.Label(window, text='项目实践GUI模块', bg='red', font=('Arial', 12),
                 width=15, height=2)

    #定义Tk变量
    scatterVar = tk.IntVar()
    axes3DVar = tk.IntVar()
    trisurfVar = tk.IntVar()
    floatVar = tk.IntVar()
    intVar = tk.IntVar()

    #创建复选框
    scatter = tk.Checkbutton(window, text='二维散点图', variable=scatterVar, onvalue=1, offvalue=0, font=('Arial', 12))
    axes3D = tk.Checkbutton(window, text='三维散点图', variable=axes3DVar, onvalue=1, offvalue=0, font=('Arial', 12))
    trisurf = tk.Checkbutton(window, text='三维剖分图', variable=trisurfVar, onvalue=1, offvalue=0, font=('Arial', 12))
    float = tk.Checkbutton(window, text='可视化浮点数', variable=floatVar, onvalue=1, offvalue=0, font=('Arial', 12))
    int = tk.Checkbutton(window, text='可视化整型数', variable=intVar, onvalue=1, offvalue=0, font=('Arial', 12))

    #安置在窗口上
    L.pack()
    scatter.place(x=20, y=100)
    axes3D.place(x=20, y=200)
    trisurf.place(x=20, y=300)
    float.place(x=220, y=100)
    int.place(x=220, y=200)

    def click():
        if (intVar.get() == 1):
            x, y, z = DrawPicture.statistics(collection, 'int')
            if(scatterVar.get() == 1):
                DrawPicture.drawScatter(x, y, z, 'int')
            if(axes3DVar.get() == 1):
                DrawPicture.drawAxes3D(x, y, z, 'int')
            if(trisurfVar.get() == 1):
                DrawPicture.drawTrisurf(x, y, z, 'int')
        elif (floatVar.get() == 1):
            x, y, z = DrawPicture.statistics(collection, 'float')
            if(scatterVar.get() == 1):
                DrawPicture.drawScatter(x, y, z, 'float')
            if(axes3DVar.get() == 1):
                DrawPicture.drawAxes3D(x, y, z, 'float')
            if(trisurfVar.get() == 1):
                DrawPicture.drawTrisurf(x, y, z, 'float')
        plt.show()

    #创建画图按钮
    b = tk.Button(window, text='开始绘图', width=10, height=2, command=click)
    b.place(x=150, y=400)
    window.mainloop()
