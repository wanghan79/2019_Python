#coding:utf8
from pymongo import MongoClient

class   Connect_Db:
    """Summary of class here.

    This class is used to connect to the mongodb database and provide
    an interface to insert and determine whether the database and collection exist.

    Attributes:
        dbhost: A string of MongoDB's IP, defaults to "localhost"
        dbport: An integer of Port, default is "12345"
        DBName: The name of the database that stores the random data
        CollectionName: The name of the collection that stores random data

    """
    def connet_db(self, dbhost='localhost', dbport=12345):
        """
        :param dbhost: MongoDB数据库连接的地址
        :param dbport: MongoDB数据库连接的接口
        :return: 数据库、集合、代理的接口
        """
        Client = MongoClient(host=dbhost, port=dbport)
        DB = Client.randomData
        Collection = DB.points
        """
        Because the creation of the database requires
        the insertion of a piece of data, which is the overall 
        information describing the database.
        """
        Collection.insert_one({"x":-1, "y":-1, "dataname":100000})
        return DB, Collection, Client

    def isExist(self,client,CollectionName='points',DBName='randomData'):
        """
        :param client: 代理，用于查询数据库的列表
        :param CollectionName: 集合名字，用于确定集合是否存在
        :param DBName: 数据库名字，用于确定数据库是否存在
        :return: 无
        """
        dblist = client.list_database_names()
        if DBName in dblist:
            print("DataBase is existed.")
        else:
            print("Error! DataBase is not existed.")

        mydb = client[DBName]

        collist = mydb.collection_names()
        if CollectionName in collist:
            print("Collection is existed.")
        else:
            print("Error! Collection is not existed.")

    def dataInsert(self, Collection, data):
        """
        :param Collection: 数据插入的集合
        :param data: 插入的字典型数据
        :return: 插入到数据库中数据的id
        """
        return Collection.insert_one(data)

# if __name__ == '__main__':
#     MongoDB = Connect_Db()
#     db, collection, client = Mongo.connet_db()
#     MongoDB.isExist(client)

