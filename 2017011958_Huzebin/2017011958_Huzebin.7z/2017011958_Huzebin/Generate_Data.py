import random
import string as str
import math
from Connect_MongoDB import Connect_Db
class Generate_Data:
    """
    Generate_Data类别是用于创建六种随机数据，分别是字符串、整型数、
    浮点数、字符、列表、字典，才用迭代器yiled产生100000行数据单元。
    """
    def generateString(self, length=10):
        """Generate random string of  10 elements  in 26 letters and numbers 0 to 9."""
        return ''.join(random.sample(str.ascii_letters + str.digits, length))


    def generateInt(self):
        """Generate random integers between 0 and 100."""
        return random.randint(0, 100)

    def generateFloat(self):
        """Generate random floats between 0 and 100."""
        return random.uniform(0, 100)

    def generateChar(self):
        """Generate random character  in 26 letters and numbers 0 to 9."""
        return random.choice(str.ascii_letters + str.digits)

    def generateList(self, length=5):
        """Generate random list of  5 elements  in 26 letters and numbers 0 to 9."""
        return random.sample(str.ascii_letters + str.digits, length)

    def generateDirction(self, length=5):
        """"Generate random dirctions  the key is random string and the value is random integers between 0 and 100"""
        string = ''.join(random.sample(str.ascii_letters + str.digits, length))
        generatedict = {string: random.randint(1,100)}
        return generatedict

    def data_generation(self, size=1000):
        """
        :param size: 数据产生的规模大小
        :return: 以yiled，迭代器的形式小批量回传。
        """
        iteration = int(math.sqrt(size))
        for x in range(1, iteration):
            for y in range(1, iteration):
                data = {
                    "x": x,
                    "y": y,
                    "Random_String": self.generateString(),
                    "Random_Int": self.generateInt(),
                    "Random_Float": self.generateFloat(),
                    "Random_Char": self.generateChar(),
                    "Random_List": self.generateList(),
                    "Random_Dict": self.generateDirction()
                }
                yield data

    def PutIntoDataBase(self, collection):
        """
        :param collection: 插入到数据库中的集合位置
        :return: 插入元素的id
        """
        for item in Generate_Data().data_generation():
            collection.insert_one(item)


