from plot import DrawPicture
from Generate_Data import Generate_Data
from Connect_MongoDB import Connect_Db
import matplotlib.pyplot as plt
"""
    此主文件采用直接实例化Connect_Db类、Generate_Data类，
    和直接静态调用DrawPicture类，连接三个主类完成课程任务，
    GUI版本由于GUI模块Tkinker对于函数的先后定义有较为严苛的
    要求，并未做成一个独立的类，本次放置到main_GUI.py文件，
    使用面向过程的思路，实现GUI功能。

"""

if __name__ == '__main__':
    size = 1000
    #实例化MongoDB连接类
    MongoDB = Connect_Db()
    db, collection, client = MongoDB.connet_db()
    MongoDB.isExist(client)
    #实例化随机生成数据类
    GenData = Generate_Data()
    GenData.PutIntoDataBase(collection)
    #静态调用画图类
    x, y, z = DrawPicture.statistics(collection, 'int')
    DrawPicture.drawAxes3D(x, y, z, 'int')
    DrawPicture.drawScatter(x, y, z, 'int')
    DrawPicture.drawTrisurf(x, y, z, 'int')
    x, y, z = DrawPicture.statistics(collection, 'float')
    DrawPicture.drawAxes3D(x, y, z, 'float')
    DrawPicture.drawScatter(x, y, z, 'float')
    DrawPicture.drawTrisurf(x, y, z, 'float')
    plt.show()

