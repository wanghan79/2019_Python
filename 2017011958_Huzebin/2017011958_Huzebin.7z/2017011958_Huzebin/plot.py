import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d as p3d
from Generate_Data import Generate_Data
from Connect_MongoDB import Connect_Db
class DrawPicture:

    @staticmethod
    def statistics(Collection, Case):
        """
        :param Collection: 可视化数据所存入的集合位置
        :param Case: 可视化数据的选择，可选项为Random_Interger和Random_Float
        :return: 二维数据的坐标及其可视化数据的类型
        """
        x = []
        y = []
        z = []
        if Case == 'int':
            for item in Collection.find():
                if item['x'] != -1:
                    x.append(item[r'x'])
                    y.append(item[r'y'])
                    z.append(item[r'Random_Int'])
            return x, y, z

        elif Case == 'float':
            for item in Collection.find():
                if item['x'] != -1:
                    x.append(item[r'x'])
                    y.append(item[r'y'])
                    z.append(item[r'Random_Float'])
            return x, y, z

    @staticmethod
    def drawScatter(x, y, z, case):
        """
        :param x:数据中坐标X
        :param y: 数据中坐标Y
        :param z: 数据中坐标Z
        :param case: 可视化数据类型
        :return: 二维散点图
        """
        fig1 = plt.figure()
        ax = plt.subplot()
        ax.scatter(x, y, s=z, alpha=0.5)
        plt.title(case)

    @staticmethod
    def drawAxes3D(x, y, z,case):
        """
        :param x:数据中坐标X
        :param y: 数据中坐标Y
        :param z: 数据中坐标Z
        :param case: 可视化数据类型
        :return: 三维散点图
        """
        fig2 = plt.figure()
        ax = p3d.Axes3D(fig2)
        ax.scatter(x, y, z, color='black')
        ax.set_ylabel('Y')
        ax.set_xlabel('X')
        ax.set_zlabel('Z')
        plt.title(case)

    @staticmethod
    def drawTrisurf(x, y, z,case):
        """
        :param x:数据中坐标X
        :param y: 数据中坐标Y
        :param z: 数据中坐标Z
        :param case: 可视化数据类型
        :return: 三维剖面图
        """
        fig3 = plt.figure()
        ax = p3d.Axes3D(fig3)
        ax.plot_trisurf(x, y, z, color='green')
        ax.set_ylabel('Y')
        ax.set_xlabel('X')
        ax.set_zlabel('Z')
        plt.title(case)

# if __name__ == '__main__':
#     size = 100
#     MongoDB = Connect_Db()
#     db, collection, client = MongoDB.connet_db()
#     MongoDB.isExist(client)
#     for item in Generate_Data().data_generation():
#         collection.insert_one(item)
#
#     x, y, z = DrawPicture.statistics(collection, 'int')
#     DrawPicture.drawAxes3D(x, y, z)
#     DrawPicture.drawScatter(x, y, z)
#     x, y, z = DrawPicture.statistics(collection, 'float')
#     DrawPicture.drawAxes3D(x, y, z)
#     plt.show()
