import random
import string
class Creat():
    def random(self):
        for i in range(1,100000):
                rint=random.randint(556, 102582)  # 随机整数
                rfloat=random.random()*10  # 浮点数
                rstr=''.join(random.sample(string.ascii_letters + string.digits,random.randint(1,10)))  # 字符串
                dict={str(rint):rstr}  # 随机字典
                #tup1=(randomInt,randomFloat,randomChar,randomStr,dict)
                Dict = {
                    'int': rint,
                    'float': rfloat,
                    'dict': dict,
                    'string': rstr
                }
                yield Dict
m=Creat()
if __name__ == '__main__':
    f = open("123.txt", "w")
    for i in m.random():
        s = str(i)
        f.write(s + '\n')
    f.close()