from pymongo import MongoClient
from Random  import Creat
client = MongoClient()
#创建数据库
db = client['Zhengxiangyu']
name = db['first']
client = MongoClient(host='localhost', port=27017)
#端口号默认为27017是数值
m=Creat()#来自第一次作业 实例化
for j in m.random():
     res=name.insert_one(j)
     #将每条插进去